<?php

 $leave_types = ['sick'=>"Nghỉ bệnh",'maternity'=>'Nghỉ thai sản','study'=>'Nghỉ tập huấn','emergency'=>'Nghỉ đột xuất','others'=>'Khác ...'];
 
 $arr = ['sick','maternity','study','emergency','others'];