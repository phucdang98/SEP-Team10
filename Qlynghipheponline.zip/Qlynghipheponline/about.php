<?php
include_once("header.php");
?>
<div class="container my-5">
    <div class="card col-md-8">
        <h1 class="text-center">Leave Manager - Docs</h1>
        <p>Trang này được viết cho project SEP 2019 của khoa Công nghệ thông tin trường đại học Văn Lang</p>
        
        <p>Quản lý nghỉ phép, xin nghỉ phép của CBNV, GV trường. Tóm tắt:
<p>- Quản lý các loại nghỉ phép của trường, mỗi loại nghỉ phép có thể có các biểu mẫu đi kèm, mô tả, ....</p>
<p>- Xem được số ngày phép, số lần nghỉ</p>
<p>- Khi user submit ngày nghỉ phép sẽ tự động gửi mail cho supervisor và có thể cho những người liên quan biết.
</p>
       