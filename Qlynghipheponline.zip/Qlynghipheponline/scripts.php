<?php

echo '<script src="js/jquery.js"></script>

    <script src="bootstrap/js/bootstrap.bundle.min.js"></script>

    <script src="js/main.js"></script>';
?>