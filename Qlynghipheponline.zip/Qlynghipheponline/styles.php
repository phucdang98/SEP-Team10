<link href="./bootstrap/css/bootstrap.min.css" rel="stylesheet">

<link href="./css/font-awesome.css" rel="stylesheet">

<link href="./css/main.css" rel="stylesheet">