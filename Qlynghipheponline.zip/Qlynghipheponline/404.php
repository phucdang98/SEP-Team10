<?php
include_once("header.php");
?>
<div class="container mt-lg mt-5">
    <div class="col-auto">
        <h1>
            Ooops! That was an error!!
        </h1>
        <p>The page you're looking for might have been moved somewhere, deleted,
        currently unavailable or you have no permission to access it.</p>
        <p>Here are some links you may try to get the problem solved</p>
        <ul>
            <li>
                <a href=".">Homepage</a>
            </li>
            <li>
                <a href="account.php">My Account</a>
            </li>
            
            <li>
                <a href="register.php">Register for Account</a>
            </li>
            
        </ul>
    </div>
</div>